<?php require('connection.php');?>


					<?php

					error_reporting(1);
					$rno=trim($_POST["rno"]);
					$fname=$_POST["fname"];
					$lname=$_POST["lname"];
					$Address=$_POST["Address"];
					$City=$_POST["City"];
					$State=$_POST["State"];
					$ZIP=$_POST["ZIP"];
					$PhoneNO=$_POST["PhoneNO"];
					echo $fname,$lname,$Address,$City,$State,$ZIP,$PhoneNO;
					
mysql_query("update personinfo set Fname='".$fname."',Lname='".$lname."',Address='".$Address."',City='".$City."',State='".$State."',ZIP='".$ZIP."',Phoneno='".$PhoneNO."' where dno='".$rno."'");
							 echo "<tr><td align=center><font size=4 color=green>Successfully Records Updated</font></td></tr>";
							 header('location:dlist.php');
						

