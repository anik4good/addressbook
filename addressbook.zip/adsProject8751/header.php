<?php $user= $_SESSION['admin'];

if ($user=="user") {
 	$aa="disabled";
 	header('alist.php');
 }
 else {
  	$aa="";
  } 
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>
	/* a.waves-effect.waves-green.btn-large.z-depth-5
	{
		display: none;
	} */


</style>
	<meta charset="UTF-8">
	<title>ADDRESS BOOK</title>
</head>
<body>
	<tr>
						<td align="center"><div class="card-panel  teal lighten-3 center z-depth-5"><h2 class="">ADDRESS BOOK</h2></div></td>
					</tr>
						
</body>
</html>