<?php require('connection.php');
?>
<html>
		<head>
			<title>All Persons List</title>
			<link rel="stylesheet" href="css/bootstrap.css"/>

 <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>


		</head> 
	<body>

	
	
		<table class="table">
				<?php include 'header.php'; ?>
						<tr bgcolor="green">
							<td ><font size=4 color=white>Persons List</font></td>
						</tr>
						<tr>
							<td><a href=dadd.php class="waves-effect waves-light btn z-depth-5">Add New Record</a></td>
						</tr>
						<tr>
							<td>
							 <div class="row">
     						 <div class="col s3">
      	
   							   </div>
							 <div class="col s6">
								<table class="card z-depth-5" width=750 cellspacing=0 cellpadding=5>
									<tr bgcolor="green">
						
						</tr>
						
									<tr  bgcolor="#4CAF50">
										<td align=center>ID</td>
										<td align=center>First Name</td>
										<td align=center>Last Name</td>
										<td align=center>Address</td>
										<td align=center>City</td>
										<td align=center>State</td>
										<td align=center>ZIP</td>
										<td align=center>Phone No</td>
										<td align=center bgcolor="red">Action</td>
									</tr>
										<?php


										$rs1=mysql_query("SELECT * from personinfo where dshow='Y' order by Fname;");
										$sno=1;
										while( $row=mysql_fetch_array($rs1))
										 {
											echo "<tr>
													<td>$sno</td>
													<td>$row[1]</td>
													<td>$row[2]</td>
													<td>$row[3]</td>
													<td>$row[4]</td>
													<td>$row[5]</td>
													<td>$row[6]</td>
													<td>$row[7]</td>
													<td><a href=dmod.php?rno=".$row[0].">Modify</a> | <a href=ddel.php?rno=".$row[0].">Delete</a></td>
												</tr>";
											$sno++;
										}
										if ($sno==1) echo "<tr><td align=center><font size=4 color=red>Records Not Found</font></td></tr>";
										?>
								</table>
								</div>
							</td>
						</tr>
								<tr>
									<td align=center><hr></td>
								</tr>
								<tr bgcolor=#80deea>
									<td><font size=4 color=white>Deleted Records</font></td>
								</tr>
									<tr>
										<td>
											<div class="row">
	     									<div class="col s3">
	      	
	   										 </div>
											<div class="col s6">
												<table class="card z-depth-5" width="auto" cellspacing=0 cellpadding=5>
														<tr bgcolor="#00BCD4">
															<td align=center>ID</td>
										<td align=center>First Name</td>
										<td align=center>Last Name</td>
										<td align=center>Address</td>
										<td align=center>City</td>
										<td align=center>State</td>
										<td align=center>ZIP</td>
										<td align=center>Phone No</td>
										<td align=center bgcolor="red">Action</td>
														</tr>

														<?php
															$rs2=mysql_query("SELECT * from personinfo where dshow='N' order by Fname;");
															$sno=1;
															while( $row=mysql_fetch_array($rs2)) {

																echo "<tr>
																			<td>$sno</td>
																			<td>$row[1]</td>
																			<td>$row[2]</td>
																			<td>$row[3]</td>
																			<td>$row[4]</td>
																			<td>$row[5]</td>
																			<td>$row[6]</td>
																			<td>$row[7]</td>
																			<td><a href=dundel.php?rno=".$row[0].">Undelete</a></td>
																	</tr>";
																$sno++;
															}
															if ($sno==1) echo "<tr>
																					<td align=center><font size=4 color=red>Records Not Found</font></td>
																				</tr>";
														?>
												</table>
												</div>
										</td>
									</tr>
		</table>
	
	</body>
						
</html> 