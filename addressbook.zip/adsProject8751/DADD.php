<?php require('connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	//error_reporting(1);
					$fname=$_POST["fname"];
					$lname=$_POST["lname"];
					$Address=$_POST["Address"];
					$City=$_POST["City"];
					$State=$_POST["State"];
					$ZIP=$_POST["ZIP"];
					$PhoneNO=$_POST["PhoneNO"];
					echo $fname,$lname,$Address,$City,$State,$ZIP,$PhoneNO;
					//$error=0;
						
					insert($fname,$lname,$Address,$City,$State,$ZIP,$PhoneNO);
}
				
					
 ?>
			



<html>
	<head>
		<title>Add New Person Entry</title>
		<link rel="stylesheet" href="css/bootstrap.css"/>
 		<link rel="stylesheet" href="css/v4/bootstrap.css"/>
	</head>
	<body>
	<table class="table table-bordered">
		<?php include 'header.php'; ?>


		<tr bgcolor=red><td ><font size=4 color=white>Add Person</font></td></tr>
			<form name=fdadd method=post action=>
				<tr><td>
					<table width=750 cellspacing=0 cellpadding=5>
						<tr><td>First Name</td><td><input type=text name=fname size=30 maxlength=30 required></td></tr>
						<tr><td>Last Name</td><td><input type=text name=lname size=30 maxlength=30 required></td></tr>
						<tr><td>Address</td><td><textarea class="form-control" name="Address" id="Address" rows="3"></textarea></td></tr>
						<tr><td>City</td><td><input type=text name=City size=30 maxlength=30 required></td></tr>
						<tr><td>State</td><td><input type=text name=State size=30 maxlength=30 required></td></tr>
						<tr><td>ZIP</td><td><input type=text name=ZIP size=30 maxlength=30 required></td></tr>
						<tr><td>PhoneNO</td><td><input type=text name=PhoneNO size=30 maxlength=30 required></td></tr>
						
					</table>
				</td></tr>

				<tr><td align=center><input  class="btn btn-outline-success btn-lg btn-block" type="submit" value=Submit></td></tr>
			</form>
	</table>
</body>
</html>