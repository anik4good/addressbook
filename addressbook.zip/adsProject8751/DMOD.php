<html>
 <head>
   <title>Modify Person Info</title>
 <link rel="stylesheet" href="css/bootstrap.css"/>

  <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 </head> 
 <body>
			<table class="table table-bordered">
					<?php include 'header.php'; ?>
				
				<?php
					require('connection.php');
						error_reporting(1);
						$rno=trim($_GET["rno"]);
						$rs1=mysql_query("SELECT * from personinfo where dno='".$rno."'");
						$sno=1;
						while( $row=mysql_fetch_array($rs1))
						 {
						 echo "<tr bgcolor=red><td ><font size=4 color=white>Edit Person Details</font></td></tr>";
						 echo "<form name=fdmod method=post action=dupdate.php>";
						 echo "<tr><td><table width=750 cellspacing=0 cellpadding=5>";
						

						echo "<tr><td>First Name</td><td><input type=text name=fname size=30 maxlength=30 value='".$row[1]."' required></td></tr>";
						echo "<tr><td>Last Name</td><td><input type=text name=lname size=30 maxlength=30 value='".$row[2]."' required></td></tr>";
						echo "<tr><td>Address</td><td><input type=text name=Address size=30 maxlength=30 value='".$row[3]."' required></td></tr>";
						echo "<tr><td>City</td><td><input type=text name=City size=30 maxlength=30 value='".$row[4]."' required></td></tr>";
						echo "<tr><td>State</td><td><input type=text name=State size=30 maxlength=30 value='".$row[5]."' required></td></tr>";
						echo "<tr><td>ZIP</td><td><input type=text name=ZIP size=30 maxlength=30 value='".$row[6]."' required></td></tr>";
						echo "<tr><td>PhoneNO</td><td><input type=text name=PhoneNO size=30 maxlength=30 value='".$row[7]."' required></td></tr>";


						 echo "</table></td></tr>";
						 echo "<tr><td colspan=2 align=center><input type=hidden name=rno value=".$rno."><input type=submit value=Submit></td></tr>";
						 echo "</form>";
						 $sno++;
						}

						if ($sno==1) echo "<tr><td align=center><font size=4 color=red>Records Not Found</font></td></tr>";
						?>
			</table>
</body>
</html> 