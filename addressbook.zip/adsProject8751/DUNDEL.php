
					<?php
					require('connection.php');
					error_reporting(1);
					$rno=$_GET["rno"];
				 	mysql_query("update doct set dshow='Y' where dno='$rno'");
				  	header('location:dlist.php');
	