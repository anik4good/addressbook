<h3 style="background:#990000;padding:20px;color:#FFFFFF;margin:0px">
	<span>Hello <?php echo $row[1]; ?></span>
	<span style="float:right"><a style="text-decoration: none; color:#FFFFFF " href="logout.php">Logout</a></span>
</h3>