<?php require('connection.php');
error_reporting(1);
$todel=$_GET['rno'];
mysql_query("update personinfo SET dshow='N' where dno='$todel' ;");
header('location:dlist.php');
?>
