<?php 
session_start();
error_reporting(1);



 function insert($fname,$lname,$Address,$City,$State,$ZIP,$PhoneNO)
{
	
					 
						mysql_query("insert into personinfo(Fname,Lname,Address,City,State,ZIP,Phoneno,dshow) values('".$fname."','".$lname."','".$Address."','".$City."','".$State."','".$ZIP."','".$PhoneNO."','Y')");

						
						echo "<tr><td align=center><font size=4 color=green>Successfully Records Inserted</font></td></tr>";
						header('location:dlist.php');
					}


					


if(!mysql_connect("localhost","root",""))
 {
  echo "<tr><td><font color=red size=4>Connection Error</font></td></tr>";
  die();
 }

 mysql_connect("localhost","root","");
 mysql_select_db("addressbook");
$que=mysql_query("select * from admin");
	 $row=mysql_fetch_array($que);
	$user= $_SESSION['admin'];

 
if($_SESSION['admin']=="")
{
header('index.php');
}
 
?>
<h3 style="background:#990000;padding:20px;color:#FFFFFF;margin:0px">
	<span>Hello <?php echo $user; ?></span>
	<span style="float:right"><a style="text-decoration: none; color:#FFFFFF " href="logout.php">Logout</a></span>
</h3>